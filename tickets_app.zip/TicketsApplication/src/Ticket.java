import java.util.ArrayList;
import java.util.List;

/**
 * Esta clase contiene los atributos y m�todos de un ticket
 * @author Sof�a Mendoza Guti�rrez
 * @version 26/08/2022
 */
public class Ticket {
	
	/** 
	 * Lista de productos contenidos en el ticket
	 */
	List<Product> products;
	
	/** 
	 * Suma total de los impuestos aplicados a los productos contenidos en el ticket
	 */
	double totalTax;
	
	/** 
	 * Suma total del precio de los productos contenidos en el ticket incluyendo los impuestos
	 */
	double totalPrice;
	
	/**
     * Constructor de un ticket
     */
	Ticket () {
		products = new ArrayList<Product>();
		totalTax = 0;
		totalPrice = 0;
	}
	
	/**
     * M�todo que devuelve la lista de productos del ticket
     * @return La lista de productos del ticket
     */
	public List<Product> getProducts() {
		return products;
	}

	/**
     * A�ade un producto al ticket, habi�ndole aplicado los impuestos necesarios a su precio.
     * Actualiza el precio total y los impuestos totales del ticket.
     * @param product Producto original que se a�ade al ticket tras aplicarle los impuestos a su precio
     */
	public void addProduct (Product product) {
		Product p = product;
		double productPrice = p.getPrice();
		
		if(p.getSalesTax()) {		
			double salesTax  = Math.ceil(productPrice*0.1/ 0.05) * 0.05;
			totalTax += salesTax;
			p.setPrice(Math.round((productPrice+salesTax) * 100.0) / 100.0);
		}
		
		if(p.getImported()) {
			double importedTax  =  Math.ceil(productPrice*0.05/ 0.05) * 0.05;			
			totalTax += importedTax;
			p.setPrice(Math.round((p.getPrice()+importedTax) * 100.0) / 100.0);
		}
		
		totalTax = Math.round(totalTax*100.0)/100.0;
		products.add(p);		
		totalPrice += p.getPrice();
		totalPrice = Math.round(totalPrice*100.0)/100.0;
	}
	
	/**
     * Devuelve una cadena con los detalles del ticket.
     */
	@Override
	public String toString() {
		
		String result = "";
		
		for (int i=0; i<products.size(); i++) {
			result += "1 " + products.get(i).getName() + ": " + String.format("%.2f", products.get(i).getPrice()) + " �\n";
		}
			
		if (totalTax!=0) result += "Impuestos sobre las ventas: " + String.format("%.2f", totalTax) + " �\n";
		
		result += "Total: " + String.format("%.2f", totalPrice) + " �\n";
		
		return result;
	}
	
}
