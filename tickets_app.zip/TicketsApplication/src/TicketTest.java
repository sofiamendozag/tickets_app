import static org.junit.Assert.*;


import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;


/**
 * @author Sof�a Mendoza
 *
 */
public class TicketTest {

	/**
	 * Test method for {@link Ticket#getProducts()}.
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	@Test
	public void testGetProducts() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		final Ticket instance = new Ticket();
        final Field field = instance.getClass().getDeclaredField("products");
        field.setAccessible(true);        
		Product p = new Product("perfume importado", 3.4, true, true);        
        List<Product> products = new ArrayList<Product>();
        products.add(p);
		field.set(instance, products);

        //when
        final List<Product> result = instance.getProducts();

        //then
        assertEquals("field wasn't retrieved properly", result, products);
	}
	
	/**
	 * Test method for {@link Ticket#addProduct(Product)}.
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	@Test
	public void testAddProduct() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		
		// Se inicializa un Ticket
		Ticket instance = new Ticket();
		double price1 = 85.49;
		double price2 = 10.23;
		double price3 = 4.31;
		
		// Se declaran tres productos
		Product p1 = new Product("perfume importado", price1, true, true);
		Product p2 = new Product("bombones", price2, false, false);
		Product p3 = new Product("CD", price3, true, false);

		// Se a�aden los tres productos al ticket
		instance.addProduct(p1);
		instance.addProduct(p2);
		instance.addProduct(p3);

		// Calcular los precios de los productos aplicando los impuestos
		double salesTax1 = Math.ceil(price1 * 0.1 / 0.05) * 0.05;
		double importedTax1 = Math.ceil(price1 * 0.05 / 0.05) * 0.05;		
		double finalPrice1 = Math.round((Math.round((price1 + salesTax1) * 100.0) / 100.0 + importedTax1) * 100.0) / 100.0;
		
		double finalPrice2 = Math.round(price2 * 100.0) / 100.0;
		
		double salesTax3 = Math.ceil(price3 * 0.1 / 0.05) * 0.05;
		double finalPrice3 = Math.round((price3 + salesTax3) * 100.0) / 100.0;
		
		double valueTotalTax = Math.round((salesTax1 + importedTax1 + salesTax3)*100.0)/100.0;
		double valueTotalPrice = Math.round((finalPrice1 + finalPrice2 + finalPrice3)*100.0)/100.0;
		
		// Atributos de ticket
		final Field fieldTotalTax = instance.getClass().getDeclaredField("totalTax");
		final Field fieldTotalPrice = instance.getClass().getDeclaredField("totalPrice");
		
		// Probar que se a�aden los productos al ticket
		assertTrue("Products didn't added", instance.getProducts().size()==3);
		
		// Comprobar que se aplican los impuestos cuando es necesario
		assertTrue("Final price of the product 1 added didn't match", instance.getProducts().get(0).getPrice()==finalPrice1);
		assertTrue("Final price of the product 2 added didn't match", instance.getProducts().get(1).getPrice()==finalPrice2);
		assertTrue("Final price of the product 3 added didn't match", instance.getProducts().get(2).getPrice()==finalPrice3);

		// Comprobar que se suman correctamente los valores de los impuestos totales y el precio total del ticket
        assertEquals("Fields didn't match", fieldTotalTax.get(instance), valueTotalTax);
        assertEquals("Fields didn't match", fieldTotalPrice.get(instance), valueTotalPrice);

	}


}
