import java.util.Scanner;

/**
 * Clase main de la aplicaci�n
 * @author Sof�a Mendoza Guti�rrez
 * @version 26/08/2022
 */
public class Main {

	/**
     * Se ofrece un men� con distintas opciones: a�adir productos a un ticket, generar el
     * ticket y mostrar el coste desglosado, mostrar los resultados de la prueba del 
     * ejemplo y detener la ejecuci�n 
     */
	public static void main(String[] args) {
		
		String input = "";
        Scanner scanner = new Scanner (System.in); //Creaci�n de un objeto Scanner
                
        Ticket t = new Ticket();
        
        while(!input.equals("4")) {
        	        	
        	System.out.println("Seleccione el n�mero correspondiente a la acci�n que desea realizar:");
            System.out.println("1. A�adir un producto al ticket");
            System.out.println("2. Generar ticket y mostrar coste desglosado");
            System.out.println("3. Mostrar resultados de la prueba de ejemplo");
            System.out.println("4. Salir");
            
            input = scanner.nextLine(); //Se lee una l�nea mediante el Scanner
            
            switch (input) {
            case "1":
            	Product p = new Product();
	        	
	        	System.out.println("Escriba el nombre del producto");
	        	input = scanner.nextLine();
	        	p.setName(input);
	        	
	        	System.out.println("Escriba el precio del producto (formato de ejemplo: 12.54)");
	        	input = scanner.nextLine();
        		p.setPrice(Double.parseDouble(input));
	        	
	        	System.out.println("�El producto es un libro, alimento o producto m�dico? S/N");
	        	input = scanner.nextLine();

	        	while (!input.equals("S") && !input.equals("N")) {
	        		System.out.println("Esa opci�n no es v�lida, seleccione S o N");
	        		input = scanner.nextLine();
	        	}
	        	
	        	if(input.equals("S")) p.setSalesTax(false);
	        	else if (input.equals("N")) p.setSalesTax(true);
	        	
	        	System.out.println("�Es un producto importado sin exenciones? S/N");
	        	input = scanner.nextLine();
	        	
	        	while (!input.equals("S") && !input.equals("N")) {
	        		System.out.println("Esa opci�n no es v�lida, seleccione S o N");
	        		input = scanner.nextLine();
	        	}
	        	
	        	if(input.equals("S")) p.setImported(true);
	        	else p.setImported(false);
	        	
	        	t.addProduct(p); 
	        	System.out.println("Producto a�adido correctamente");
            	break;           
            
            case "2":
            	System.out.println(t.toString());
 	        	t = new Ticket();
 	        	break;
 	        
            case "3":
            	Product p1 = new Product("libro", 12.49, false, false);
	    		Product p2 = new Product ("CD de m�sica", 14.99, true, false);
	    		Product p3 = new Product ("barrita de chocolate", 0.85, false, false);
	    		
	    		Ticket t1 = new Ticket();
	    		
	    		t1.addProduct(p1);
	    		t1.addProduct(p2);
	    		t1.addProduct(p3);
	    		
	    		System.out.println(t1.toString());
	    		
	    		Product p4 = new Product("caja de bombones importados", 10, false, true);
	    		Product p5 = new Product ("frasco de perfume importado", 47.50, true, true);
	    		
	    		Ticket t2 = new Ticket();
	    		
	    		t2.addProduct(p4);
	    		t2.addProduct(p5);
	    		
	    		System.out.println(t2.toString());
	    		
	    		Product p6 = new Product("frasco de perfume importado", 27.99, true, true);
	    		Product p7 = new Product ("frasco de perfume", 18.99, true, false);
	    		Product p8 = new Product ("caja de pastillas para el dolor de cabeza", 9.75, false, false);
	    		Product p9 = new Product ("caja de bombones importados", 11.25, false, true);
	    		
	    		Ticket t3 = new Ticket();
	    		
	    		t3.addProduct(p6);
	    		t3.addProduct(p7);
	    		t3.addProduct(p8);
	    		t3.addProduct(p9);
	    		
	    		System.out.println(t3.toString());
	    		break;
            
            case "4":
            	System.out.println("La ejecuci�n ha finalizado");
	    		break;
	    		
            default:
            	System.out.println("Esa opci�n no es v�lida, seleccione otra");
	    		break;
            }                      
        }
        scanner.close();
	}
}
