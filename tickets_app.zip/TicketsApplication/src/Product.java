
/**
 * Esta clase contiene los atributos y m�todos de un producto
 * @author Sof�a Mendoza Guti�rrez
 * @version 26/08/2022
 */
public class Product {
	
	/** 
	 * Nombre del producto
	 */
	String name;
	
	/** 
	 * Precio del producto
	 */
	double price;
	
	/** 
	 * Toma el valor true cuando al producto se le debe aplicar el impuesto b�sico 
	 * sobre las ventas, toma el valor false en caso contrario
	 */
	boolean salesTax;
	
	/** 
	 * Toma el valor true cuando al producto se le deben aplicar las tasas de derechos 
	 * de importaci�n sobre las ventas, toma el valor false en caso contrario
	 */
	boolean imported;
	
	/**
     * Constructor de un producto
     */
	Product () {
		name = "";
		price = 0;
		salesTax = false;
		imported = false;
	}
	/**
     * Constructor parametrizado de un producto
     * @param pName El par�metro pName define el nombre del producto
     * @param pPrice El par�metro pPrice define el precio del producto
     * @param pSalesTax El par�metro pSalesTax define se le debe aplicar el impuesto b�sico 
	 * sobre las ventas al producto
     * @param pImported El par�metro pImported define si se le deben aplicar las tasas de 
     * derechos de importaci�n sobre las ventas al producto
     */
	Product (String pName, double pPrice, boolean pSalesTax, boolean pImported) {
		name = pName;
		price = pPrice;
		salesTax = pSalesTax;
		imported = pImported;
	}
	
	/**
     * Establece el nombre del producto
     * @param pName Nombre que se le asigna al producto
     */
	public void setName(String pName) {
		name = pName;
	}

	/**
     * Establece el precio del producto
     * @param pPrice Precio que se le asigna al producto
     */
	public void setPrice(double pPrice) {
		price = pPrice;
	}
	
	/**
     * Establece si se le debe aplicar el impuesto b�sico sobre las ventas al producto
     * @param pSalesTax valor que se le asigna al atributo salesTax del producto
     */
	public void setSalesTax(boolean pSalesTax) {
		salesTax = pSalesTax;
	}
	
	/**
     * Establece si se le deben aplicar las tasas de derechos de importaci�n sobre
     * las ventas al producto
     * @param pImported valor que se le asigna al atributo imported del producto
     */
	public void setImported(boolean pImported) {
		imported = pImported;
	}
	
	/**
     * M�todo que devuelve el nombre del producto
     * @return El nombre del producto
     */
	public String getName() {
		return name;
	}
	
	/**
     * M�todo que devuelve el precio del producto
     * @return El precio del producto
     */
	public double getPrice() {
		return price;
	}

	/**
     * M�todo que devuelve si se le debe aplicar el impuesto b�sico sobre las ventas al producto
     * @return Si se le debe aplicar el impuesto b�sico sobre las ventas al producto
     */
	public boolean getSalesTax() {
		return salesTax;
	}

	/**
     * M�todo que devuelve si se le deben aplicar las tasas de derechos de importaci�n sobre
     * las ventas al producto
     * @return Si se le deben aplicar las tasas de derechos de importaci�n sobre las ventas 
     * al producto
     */
	public boolean getImported() {
		return imported;
	}

}
