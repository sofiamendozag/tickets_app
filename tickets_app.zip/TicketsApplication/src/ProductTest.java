/**
 * 
 */


import static org.junit.Assert.*;

import java.lang.reflect.Field;

import org.junit.Test;

/**
 * @author Sof�a Mendoza
 *
 */
public class ProductTest {

	/**
	 * Test method for {@link Product#setName(java.lang.String)}.
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	@Test
	public void testSetName() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		String value = "ordenador";
        Product instance = new Product();
        instance.setName(value);
        final Field field = instance.getClass().getDeclaredField("name");
        field.setAccessible(true);
        assertEquals("Fields didn't match", field.get(instance), value);
	}

	/**
	 * Test method for {@link Product#setPrice(double)}.
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	@Test
	public void testSetPrice() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		double value = 1.99999999999;
        Product instance = new Product();
        instance.setPrice(value);
        final Field field = instance.getClass().getDeclaredField("price");
        field.setAccessible(true);
        assertEquals("Fields didn't match", field.get(instance), value);
	}
	
	/**
	 * Test method for {@link Product#setSalesTax(boolean)}.
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	@Test
	public void testSetSalesTax() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		boolean value = true;
        Product instance = new Product();
        instance.setSalesTax(value);
        final Field field = instance.getClass().getDeclaredField("salesTax");
        field.setAccessible(true);
        assertEquals("Fields didn't match", field.get(instance), value);
	}
	
	/**
	 * Test method for {@link Product#setImported(boolean)}.
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	@Test
	public void testSetImported() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		boolean value = true;
        Product instance = new Product();
        instance.setImported(value);
        final Field field = instance.getClass().getDeclaredField("imported");
        field.setAccessible(true);
        assertEquals("Fields didn't match", field.get(instance), value);
	}

	/**
	 * Test method for {@link Product#getName()}.
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	@Test
	public void testGetName() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		final Product instance = new Product();
        final Field field = instance.getClass().getDeclaredField("name");
        field.setAccessible(true);
        field.set(instance, "ordenador");

        //when
        final String result = instance.getName();

        //then
        assertEquals("field wasn't retrieved properly", result, "ordenador");
	}

	/**
	 * Test method for {@link Product#getPrice()}.
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	@Test
	public void testGetPrice() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		final Product instance = new Product();
        final Field field = instance.getClass().getDeclaredField("price");
        field.setAccessible(true);
        field.set(instance, 1.99999999999);

        //when
        final double result = instance.getPrice();

        //then
        assertEquals("field wasn't retrieved properly", result, 1.99999999999, 0);
	}

	/**
	 * Test method for {@link Product#getSalesTax()}.
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	@Test
	public void testGetSalesTax() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		final Product instance = new Product();
        final Field field = instance.getClass().getDeclaredField("salesTax");
        field.setAccessible(true);
        field.set(instance, true);

        //when
        final boolean result = instance.getSalesTax();

        //then
        assertEquals("field wasn't retrieved properly", result,true);
	}

	/**
	 * Test method for {@link Product#getImported()}.
	 * @throws SecurityException 
	 * @throws NoSuchFieldException 
	 * @throws IllegalAccessException 
	 * @throws IllegalArgumentException 
	 */
	@Test
	public void testGetImported() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		final Product instance = new Product();
        final Field field = instance.getClass().getDeclaredField("imported");
        field.setAccessible(true);
        field.set(instance, true);

        //when
        final boolean result = instance.getImported();

        //then
        assertEquals("field wasn't retrieved properly", result, true);
	}

}
